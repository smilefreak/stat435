#!/bin/bash
cp .vandevijver-CLIN-STAT435.csv  vandevijver-CLIN-STAT435.csv 
